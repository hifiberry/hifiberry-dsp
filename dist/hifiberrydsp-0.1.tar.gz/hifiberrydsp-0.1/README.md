# HiFiberry DSP

Software for HiFiBerry boards equipped with DSP. This package can be used to read/write data to HiFiBerry DSP boards
using the Beocreate TCP server.

## REW integration

The software can be used to push filters created by Room Equalisation Wizard (REW) to the DSP.
